# ShqipFlix (website starter)

This is a responsive, static website starter. It is empty by default and works on Android/iPhone browsers.

## Add movies
Open `index.html` and find `const movies = [` near the bottom. Add entries like:
`{title:"Titulli", year:"2026", poster:"poster.jpg", video:"https://YOUR-HOST/video.mp4"}`
Use video files/streams you own or are authorized to publish. A direct MP4/WebM URL is needed for the built-in player.

## Publish free with GitHub Pages
1. Create/sign in to a GitHub account at https://github.com
2. Create a public repository named `shqipflix`.
3. Upload `index.html` (and any poster images) to the repository root.
4. Repository → Settings → Pages → Deploy from a branch → `main` / root → Save.
5. GitHub will show your public website URL, usually `https://YOUR-USERNAME.github.io/shqipflix/`.

## Important
- Hosting this static site is free on GitHub Pages, but video storage/bandwidth is NOT included as a movie streaming service. Host videos separately with a provider that permits your use.
- This starter has no secure admin login/upload panel. Only edit the catalog through your GitHub repository (keep repository access private to yourself; Pages can still publish a public site from a public repo). Never put passwords/API secrets in HTML.
- Google Search indexing is not instant or guaranteed. Submit the published URL in Google Search Console after launch.
- Publish only films/videos you own or have permission to distribute.
